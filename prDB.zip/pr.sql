-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 12 2023 г., 10:13
-- Версия сервера: 10.8.4-MariaDB
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `pr`
--

-- --------------------------------------------------------

--
-- Структура таблицы `coterie`
--

CREATE TABLE `coterie` (
  `id` int(11) NOT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_age` int(2) DEFAULT NULL,
  `image` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `coterie`
--

INSERT INTO `coterie` (`id`, `title`, `description`, `from_age`, `image`) VALUES
(1, 'Программирование', NULL, 6, 'programmirovanie.jpg'),
(2, 'Робототехника', NULL, 7, 'robototekhnika.jpeg'),
(3, 'Компьютерный дизайн', NULL, 7, 'komputerniy_dizain.jpg'),
(4, 'Рисование', NULL, 6, 'risovanie.jpg'),
(5, 'Драма', NULL, 8, 'drama.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `day_of_week`
--

CREATE TABLE `day_of_week` (
  `id` int(11) NOT NULL,
  `day` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `day_of_week`
--

INSERT INTO `day_of_week` (`id`, `day`) VALUES
(1, 'Понедельник'),
(2, 'Вторник'),
(3, 'Среда'),
(4, 'Четверг'),
(5, 'Пятница'),
(6, 'Суббота');

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `coterie_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`id`, `body`, `date`, `user_id`, `coterie_id`) VALUES
(1, 'rgerh', '2023-11-08 16:01:26', 2, 3),
(2, 'gerge', '2023-11-08 16:02:01', 1, 5),
(3, 'саиокпт', '2023-11-08 16:29:06', 1, 2),
(4, 'cfdf', '2023-11-08 16:31:47', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `proposal`
--

CREATE TABLE `proposal` (
  `id` int(11) NOT NULL,
  `parent_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_surname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_patronymic` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_phone` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_email` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `child_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `child_surname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `child_patronymic` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `child_age` int(2) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `coterie_id` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `proposal`
--

INSERT INTO `proposal` (`id`, `parent_name`, `parent_surname`, `parent_patronymic`, `parent_phone`, `parent_email`, `child_name`, `child_surname`, `child_patronymic`, `child_age`, `user_id`, `coterie_id`, `status`) VALUES
(1, 'Super', 'Admin', '', '+7 (937) 399-33-32', 'super.admin@gmail.com', 'Abcd', 'Abcd', '', 11, NULL, NULL, 2),
(2, 'Super', 'Admin', '', '+7 (937) 399-33-32', 'super.admin@gmail.com', 'Дмитрий', 'Предеин', 'Андреевич', 11, NULL, NULL, 1),
(3, 'Abcd', 'Abcd', '', '+7 (984) 596-48-59', 'abcd@email.com', 'Abcd', 'Abcd', '', 10, 2, NULL, 1),
(4, 'Super', 'Admin', '', '+7 (937) 399-33-32', 'super.admin@gmail.com', 'Дмитрий', 'Предеин', 'Андреевич', 10, 2, NULL, 1),
(5, 'Super', 'Admin', '', '+7 (937) 399-33-32', 'super.admin@gmail.com', 'Дмитрий', 'Предеин', 'Андреевич', 10, 2, 1, 1),
(6, 'Abcd', 'Abcd', '', '+7 (984) 596-48-59', 'abcd@email.com', 'Super', 'Admin', '', 11, 1, 3, 2),
(7, 'Super', 'Admin', '', '+79373993332', 'super.admin@gmail.com', 'Abcd', 'Abcd', '', 11, 1, 2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `coterie_id` int(11) DEFAULT NULL,
  `time` time NOT NULL,
  `day_of_week_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `schedule`
--

INSERT INTO `schedule` (`id`, `coterie_id`, `time`, `day_of_week_id`) VALUES
(1, 3, '17:10:00', 1),
(4, 1, '16:30:00', 1),
(5, 1, '16:30:00', 2),
(6, 1, '16:30:00', 3),
(7, 1, '16:30:00', 4),
(8, 1, '16:30:00', 5),
(9, 1, '17:00:00', 6),
(10, 2, '17:00:00', 1),
(11, 2, '17:00:00', 2),
(12, 2, '17:00:00', 3),
(13, 2, '17:00:00', 4),
(14, 2, '17:00:00', 5),
(15, 2, '14:20:00', 6),
(16, 3, '17:10:00', 2),
(17, 3, '17:10:00', 3),
(18, 3, '17:10:00', 4),
(19, 3, '17:10:00', 5),
(20, 3, '15:30:00', 6),
(21, 4, '15:10:00', 1),
(22, 4, '15:10:00', 2),
(23, 4, '15:00:00', 3),
(24, 4, '15:10:00', 4),
(25, 4, '15:00:00', 5),
(26, 4, '16:30:00', 6),
(27, 5, '13:30:00', 1),
(28, 5, '13:30:00', 2),
(29, 5, '13:30:00', 3),
(30, 5, '13:30:00', 4),
(31, 5, '13:00:00', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `role`) VALUES
(1, 'admin', 'admin11', 'admin@email.com', 1),
(2, 'user2', 'user22', NULL, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `coterie`
--
ALTER TABLE `coterie`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `day_of_week`
--
ALTER TABLE `day_of_week`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `coterie_id` (`coterie_id`);

--
-- Индексы таблицы `proposal`
--
ALTER TABLE `proposal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `coterie_id` (`coterie_id`);

--
-- Индексы таблицы `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `day_of_week_id` (`day_of_week_id`),
  ADD KEY `coterie_id` (`coterie_id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `coterie`
--
ALTER TABLE `coterie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `day_of_week`
--
ALTER TABLE `day_of_week`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `proposal`
--
ALTER TABLE `proposal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`coterie_id`) REFERENCES `coterie` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `proposal`
--
ALTER TABLE `proposal`
  ADD CONSTRAINT `proposal_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `proposal_ibfk_2` FOREIGN KEY (`coterie_id`) REFERENCES `coterie` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`day_of_week_id`) REFERENCES `day_of_week` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`coterie_id`) REFERENCES `coterie` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
